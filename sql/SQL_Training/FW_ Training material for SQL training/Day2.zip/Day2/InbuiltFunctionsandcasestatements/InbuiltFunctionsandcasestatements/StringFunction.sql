 SELECT REPLACE('SQL Server 2016','SQL','Microsoft SQL') 
 SELECT LEFT ('Microsoft SQL Server 2016', 9) 
 SELECT RIGHT ('Microsoft SQL Server 2016',4) 
 SELECT SubString ('Microsoft SQL Server 2016',11,10) 
  SELECT SubString ('        Microsoft SQL Server 2016',11,10) 
   SELECT '        Microsoft SQL Server 2016'
   Select Ltrim('        Microsoft SQL Server 2016')