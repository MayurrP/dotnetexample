--How to use Window Function in where condition in SQL Server

use DBase
go

SELECT 
 SalesGroup,
 Country,
 AnnualSales,
 SUM(AnnualSales) OVER(PARTITION BY SalesGroup) AS TotalSales
FROM RegionalSales
where SUM(AnnualSales) OVER(PARTITION BY SalesGroup)>100000 -- Error

GO
--SOLUTION USING COMMON TABLE EXPRESSION




--SOLUTION USING DERIVED TABLES







