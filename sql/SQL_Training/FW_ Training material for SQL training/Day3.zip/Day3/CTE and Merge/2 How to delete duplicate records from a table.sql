use DBase
go


CREATE TABLE dbo.Employee
( 
EmpID int IDENTITY(1,1) NOT NULL, 
Name varchar(55) NULL, 
Salary decimal(10, 2) NULL, 
Designation varchar(20) NULL
 ) 
 go

 insert into Employee (Name,Salary,Designation) values ('Rahul',6000,'TL')
  insert into Employee (Name,Salary,Designation) values ('Aslam',3500,'SE')
   insert into Employee (Name,Salary,Designation) values ('Rohit',5000,'SSE')
    insert into Employee (Name,Salary,Designation) values ('Aslam',3500,'SE')
	 insert into Employee (Name,Salary,Designation) values ('Rahul',6000,'TL')
	  insert into Employee (Name,Salary,Designation) values ('Sagar',3500,'SE')
	   insert into Employee (Name,Salary,Designation) values ('Rajesh',4000,'SE')

	   go

	   select * from Employee
	   go










